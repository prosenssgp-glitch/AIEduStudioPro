# AI Edu Studio Pro — Android Prototype

This is a native Android (Kotlin + Jetpack Compose) rebuild of the `AI_Edu_Studio_Pro_v2_MobileFix` HTML clickable prototype.

## What this is
A clickable native-UI prototype: top bar (save/undo/redo/export), video preview with
play/scrub, an inspector panel (opacity/scale/trim/split/etc.), an action bar
(Media/Layer/Audio/Voice/AI Studio), a multi-track timeline, an AI Studio tool drawer,
and a pre-publish safety checklist — all matching the original web prototype's layout and flow.

**Now includes real media import, playback, trim, and export:**
- **AI Studio bar → Media → Import Media** (or **Replace media** in the inspector) opens the
  Android file/photo picker (Storage Access Framework) and loads a real video into the
  preview via Media3/ExoPlayer.
- Once a video is loaded, a **Trim bar** appears under the preview with real Start/End
  handles (in mm:ss). Preview playback stops at the trim-out point automatically.
- Tapping **Export** in the top bar runs a real **Media3 Transformer** job that cuts the
  video to the trimmed range and writes an actual `.mp4` file to
  `Android/data/com.aiedu.studio/files/Movies/AIEduStudio/` on the device, with a toast
  confirming success or reporting the error.
- **Delete layer** clears the imported clip back to the empty state.

**Still placeholders** (this is where real engineering work remains): AI Quiz/Caption/Voice
generation (needs a backend + AI/TTS API), Split/Crop/Rotate/Speed/Keyframe/Mask/Chroma
(need a proper multi-track edit model), audio/voice tracks, and multi-clip timelines (only
one imported video clip is supported end-to-end right now). Tapping those still shows a
toast that's honest about not being implemented yet, instead of pretending they work.

## Build it via GitHub (no Android Studio required)

1. Create a new GitHub repository and push this folder's contents to the `main` branch:
   ```bash
   git init
   git add .
   git commit -m "Initial native Android prototype"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```
2. GitHub Actions will automatically run (see `.github/workflows/android-build.yml`) and build
   a debug APK.
3. Go to your repo → **Actions** tab → open the latest "Build Android APK" run → download the
   **ai-edu-studio-pro-debug-apk** artifact (zip). Inside is `app-debug.apk`.
4. Transfer `app-debug.apk` to your Android phone (or download it directly on the phone from
   the Actions page) and tap it to install. You'll need to allow "Install unknown apps" for
   your browser/file manager the first time.

You can also trigger a build manually anytime from the **Actions** tab using
"Run workflow" (workflow_dispatch).

## Opening it in Android Studio instead
If you later want to edit visually: File → Open → select this folder. Android Studio will
sync Gradle automatically (needs internet access for the first sync to download dependencies).

## Next steps toward a real product
- Multi-clip timeline (currently one video clip end-to-end; images/text/audio tracks are
  visual-only)
- Split/Crop/Rotate/Speed/Keyframe/Mask/Chroma as real Media3 Transformer effects
- AI Quiz/Caption/Voice generation via a backend API (OpenAI/Anthropic + a TTS service)
- Real project save/load and asset storage (Room database)
- Signing config + Play Store release build
